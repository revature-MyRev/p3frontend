export class Users {
  constructor(
    public userId: number,
    public firstName: string,
    public age: number,
    public userName: string,
    public password: string,
    public gender: string,
    public photo: string,
    public email: string,
    public lastName: string,
    public middleName: string,
    public jobTitle: string,
  ) {}
}