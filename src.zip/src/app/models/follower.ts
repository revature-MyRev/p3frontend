export interface IFollower {
    id: number;
    followerId: number;
    followedId: number;
}