import { Component, OnInit } from '@angular/core';
import { Users } from 'src/app/models/user';
import { SearchBarService } from './services/search-bar.service';
import { FilterPipe } from './services/filter.pipe';

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss']
})
export class SearchBarComponent implements OnInit {

  users!: Users[];
  searchName:string="";

  constructor(private SearchBarService: SearchBarService, private pipe: FilterPipe) { }

  ngOnInit(): void {
    this.getUsers();

  }
  // I don't know if this is needed anymore - Andrew
 
  // showProfile(userId:number): void{}


  private getUsers(){
    this.SearchBarService.getUsersList().subscribe(data=>{this.users=data})

  }

}