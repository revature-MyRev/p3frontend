import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postfeed',
  templateUrl: './postfeed.component.html',
  styleUrls: ['./postfeed.component.scss']
})
export class PostfeedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
